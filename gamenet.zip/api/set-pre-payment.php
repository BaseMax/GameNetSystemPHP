<?php
require "../_core.php";

print_r($_POST);

// price: field.value,
// planID: planID,
// planIndex: planIndex,
// planFamily: planFamily,

$_POST["playID"] = 1;
$clauses = [
	"id"=>$_POST["playID"],
];
$values = [
	"prePayment"=>$_POST["price"],
];
$db->update("plays", $clauses, $values);

